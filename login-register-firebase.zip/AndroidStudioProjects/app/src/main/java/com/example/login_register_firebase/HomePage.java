package com.example.login_register_firebase;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class HomePage extends AppCompatActivity {

    private ImageView imageView;
    private TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);

        imageView = findViewById(R.id.image_view);
        textView = findViewById(R.id.text_view);

        // Read and display the image from the asset folder
        try {
            InputStream imageStream = getAssets().open("bg2.jpg");
            Bitmap bitmap = BitmapFactory.decodeStream(imageStream);
            imageView.setImageBitmap(bitmap);
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Read and display the text file from the asset folder
        try {
            InputStream textStream = getAssets().open("Log.txt");
            BufferedReader reader = new BufferedReader(new InputStreamReader(textStream));
            StringBuilder stringBuilder = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                stringBuilder.append(line);
                stringBuilder.append("\n");
            }
            textView.setText(stringBuilder.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
